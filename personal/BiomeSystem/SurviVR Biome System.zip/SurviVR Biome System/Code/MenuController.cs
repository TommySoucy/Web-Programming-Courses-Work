﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MenuController : MonoBehaviour
{

    public Toggle toggle;

    public Toggle colorRange1;
    public Toggle colorRange255;

    public GameObject panel;

    public GameObject[] otherPanels;

    public void ToggleMenu()
    {

        if (panel != null)
        {

            //the state we want to set the panel to
            bool newState = !panel.activeSelf;

            //disable all other panels if we want to enable one
            if (newState)
            {

                foreach (GameObject go in otherPanels)
                {

                    if (go != null)
                    {

                        go.SetActive(false);

                    }

                }

            }

            //toggle panel state
            panel.SetActive(newState);

        }

    }

    public void SetEdgesVisible()
    {

        GameObject plane = GameObject.Find("Plane");
        BiomeGenerator biomeGenerator = plane.GetComponent<BiomeGenerator>();
        biomeGenerator.SetDisplayEdges(toggle.isOn);

    }

    public void SetUseFalloff()
    {

        GameObject plane = GameObject.Find("Plane");
        BiomeGenerator biomeGenerator = plane.GetComponent<BiomeGenerator>();
        biomeGenerator.SetUseFalloff(toggle.isOn);

    }

    public void SetUseAltFalloff()
    {

        GameObject plane = GameObject.Find("Plane");
        BiomeGenerator biomeGenerator = plane.GetComponent<BiomeGenerator>();
        biomeGenerator.SetUseAltFalloff(toggle.isOn);

    }

    public void SetColorRange()
    {

        GameObject plane = GameObject.Find("Plane");
        BiomeGenerator biomeGenerator = plane.GetComponent<BiomeGenerator>();
        biomeGenerator.SetColorRange(colorRange1.isOn);

    }

    public void SetSpawnSiteMarkers()
    {

        GameObject plane = GameObject.Find("Plane");
        BiomeGenerator biomeGenerator = plane.GetComponent<BiomeGenerator>();
        biomeGenerator.SetSpawnSiteMarkers(toggle.isOn);

    }

    public void SetNearestSitesToMouseVisible()
    {

        GameObject plane = GameObject.Find("Plane");
        BiomeGenerator biomeGenerator = plane.GetComponent<BiomeGenerator>();
        biomeGenerator.SetNearestSitesToMouseVisible(toggle.isOn);

    }

    public void SetNearestEdgesToMouseVisible()
    {

        GameObject plane = GameObject.Find("Plane");
        BiomeGenerator biomeGenerator = plane.GetComponent<BiomeGenerator>();
        biomeGenerator.SetNearestEdgesToMouseVisible(toggle.isOn);

    }

    public void Regenerate()
    {

        GameObject plane = GameObject.Find("Plane");
        BiomeGenerator biomeGenerator = plane.GetComponent<BiomeGenerator>();
        biomeGenerator.UpdateSettings();
        biomeGenerator.Generate();

    }

}
