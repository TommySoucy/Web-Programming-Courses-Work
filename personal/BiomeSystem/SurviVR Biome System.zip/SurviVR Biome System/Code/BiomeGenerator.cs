﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BiomeGenerator : MonoBehaviour
{

    //the UI elements we would want input from for the below settings
    public InputField jitterFractionIF;
    public Toggle useFalloffToggle;
    public Toggle useAltFalloffToggle;
    public InputField altFalloffMidValueIF;
    public InputField falloffDistanceIF;
    public Toggle displayEdgesToggle;
    public InputField edgeWidthIF;
    public InputField edgeColorRIF;
    public InputField edgeColorGIF;
    public InputField edgeColorBIF;
    public Toggle edgeColorRange1Toggle;
    public Toggle edgeColorRange256Toggle;
    public Toggle siteMarkersToggle;
    public InputField seedIF;

    //the sites of the voronoi diagram
    Vector4[] sites;

    //camera variable that will be used to process the sites to put them in screenspace
    public Camera mainCam;

    //the fraction of the jitter relative to the dist between each site
    //the higher this is, the less jitter there will be
    float jitterFraction;

    //whether we want to have falloff between the cells
    bool useFalloff;

    //whether we want to use the alternative falloff
    bool useAltFalloff;

    //the mid value for the alt falloff, the value that which pixels will be on the edges
    float midValue;

    //the distance from the edges at which falloff will begin between biomes
    float falloffDistance;
    
    //settings for edges
    bool displayEdges;
    float edgeWidth;
    Vector4 edgeColorRGBA;

    //the range for the colors of the edge color, if true range will be 0 - 1, if false it will be 0 - 255
    bool edgeColorRange1;

    //the property block through which we pass all the info to the shader
    private MaterialPropertyBlock propBlock;

    //the plane's renderer
    Renderer renderer;

    //the number of biomes we want in width (x) and in height (y)
    //this must also be set in the shader, the sites array must have a size of size.x*size.y*4
    //i hardcoded this size because i needed to set the size of the sites array in the shader using a literal scalar value, ie.: i couldnt do Sites[size.x*size.y*4] i need Sites[240] instead
    //so i need to know the value beforehand
    private readonly Vector2Int size = new Vector2Int(10, 6);

    //list of all site markers so we can destroy them when needed
    List<GameObject> siteMarkers = new List<GameObject>();

    //whether we want to spawn the site markers
    bool spawnSiteMarkers;

    //the seed for positioning of the sites
    string seed;

    //the pos of the mouse since it last moved
    Vector3 oldMousePos;

    //whether we want to see the three nearest sites to the mouse
    bool displayNearestSites;

    //whether we want to see the nearest edge to the mouse
    bool displayNearestEdges;

    private void Awake()
    {

        //init sites array
        sites = new Vector4[size.x * size.y * 4];

        //init the property block
        propBlock = new MaterialPropertyBlock();

        //render to get the material's shader we want to pass our info to
        renderer = GetComponent<Renderer>();

        //set settings depending on menu inputs
        UpdateSettings();

        //once the game starts, initially display the voronoi diagram with default settings
        Generate();

    }

    private void Update()
    {

        //to store the final mouse position in xy to pass to the shader
        Vector2 processedMousePos=Vector2.zero;

        //stuff to find the 3 nearest sites to the mouse
        Vector4 nearestSiteToMouse = Vector4.zero;
        float nearestSiteToMouseDist=float.MaxValue;
        Vector4 secondNearestSiteToMouse = Vector4.zero;
        float secondNearestSiteToMouseDist = float.MaxValue;
        Vector4 thirdNearestSiteToMouse = Vector4.zero;
        float thirdNearestSiteToMouseDist = float.MaxValue;

        //this is used to see if the second nearest site's edge or the third nearest's edge is the nearest edge
        //an attempt at having more accurate falloff
        bool nearestEdgeIsSecondNearestSite = true;

        //if the mouse has moved
        if (Input.mousePosition != oldMousePos)
        {

            //for all the sites
            for(int i=0; i<sites.Length;i++)
            {

                //convert site pos from world space to screen space
                Vector3 currentSite = mainCam.WorldToScreenPoint(sites[i]);

                //process site to have same origin as shader
                currentSite.y *= -1;
                currentSite.y += Screen.height;

                //process mousePos to have same origin as shader
                //invert y because origin from Input.mousePosition is bottom left
                //and origin in shader is top left
                //offset the y of by the height of display since after inversion the position will now always be above the display
                processedMousePos = Input.mousePosition;
                processedMousePos.y *= -1;
                processedMousePos.y += Screen.height;

                //get disatance from current site to the mouse
                float currentSiteToMouseDist = Vector3.Distance(currentSite, processedMousePos);

                //for mouse nearest
                if (currentSiteToMouseDist < nearestSiteToMouseDist)
                {

                    //set third nearest to old second nearest
                    thirdNearestSiteToMouse = secondNearestSiteToMouse;
                    thirdNearestSiteToMouseDist = secondNearestSiteToMouseDist;

                    //set second nearest to old nearest
                    secondNearestSiteToMouse = nearestSiteToMouse;
                    secondNearestSiteToMouseDist = nearestSiteToMouseDist;

                    //set nearest to current 
                    nearestSiteToMouse = currentSite;
                    nearestSiteToMouseDist = currentSiteToMouseDist;

                }
                else if (currentSiteToMouseDist < secondNearestSiteToMouseDist)
                {

                    //set third nearest to old second nearest
                    thirdNearestSiteToMouse = secondNearestSiteToMouse;
                    thirdNearestSiteToMouseDist = secondNearestSiteToMouseDist;

                    //set second nearest to current
                    secondNearestSiteToMouse = currentSite;
                    secondNearestSiteToMouseDist = currentSiteToMouseDist;

                }
                else if (currentSiteToMouseDist < thirdNearestSiteToMouseDist)
                {

                    //set third nearest to current
                    thirdNearestSiteToMouse = currentSite;
                    thirdNearestSiteToMouseDist = currentSiteToMouseDist;

                }

            }

            //get dist from mouse to site between nearest and second nearest, and nearest and third nearest
            Vector4 vectBetweenSecondNearestAndNearestSites = secondNearestSiteToMouse - nearestSiteToMouse;
            float halfDistBetweenSecondNearestAndNearestSites = vectBetweenSecondNearestAndNearestSites.magnitude / 2.0f;
            float secondNearestComponent = Vector4.Dot(nearestSiteToMouse, vectBetweenSecondNearestAndNearestSites) / vectBetweenSecondNearestAndNearestSites.magnitude;
            float distFromSecondNearestSiteEdge = halfDistBetweenSecondNearestAndNearestSites - secondNearestComponent;

            Vector4 vectBetweenThirdNearestAndNearestSites = secondNearestSiteToMouse - nearestSiteToMouse;
            float halfDistBetweenThirdNearestAndNearestSites = vectBetweenThirdNearestAndNearestSites.magnitude / 2.0f;
            float thirdNearestComponent = Vector4.Dot(nearestSiteToMouse, vectBetweenThirdNearestAndNearestSites) / vectBetweenThirdNearestAndNearestSites.magnitude;
            float distFromThirdNearestSiteEdge = halfDistBetweenThirdNearestAndNearestSites - thirdNearestComponent;

            //get which edge between the two is the nearest edge
            //true if the nearest edge is the edge betwee nnearest and second nearest, if false we assume tht the nearest edge is the edge between nearest and third nearest 
            nearestEdgeIsSecondNearestSite = distFromSecondNearestSiteEdge <= distFromThirdNearestSiteEdge;

            //pass mouse info to shader
            //only if mouse moved since last frame
            propBlock.SetVector("MousePos", processedMousePos);
            propBlock.SetVector("NearestSiteToMouse", nearestSiteToMouse);
            propBlock.SetFloat("NearestSiteToMouseDist", nearestSiteToMouseDist);
            propBlock.SetVector("SecondNearestSiteToMouse", secondNearestSiteToMouse);
            propBlock.SetFloat("SecondNearestSiteToMouseDist", secondNearestSiteToMouseDist);
            propBlock.SetVector("ThirdNearestSiteToMouse", thirdNearestSiteToMouse);
            propBlock.SetFloat("ThirdNearestSiteToMouseDist", thirdNearestSiteToMouseDist);
            propBlock.SetFloat("NearestEdgeIsSecondNearestSite", nearestEdgeIsSecondNearestSite?1:0);
            renderer.SetPropertyBlock(propBlock);

            //set the old mouse pos as this frame's if they aren't the same
            oldMousePos = Input.mousePosition;

        }

    }

    //input settings functions
    public void SetNearestSitesToMouseVisible(bool display)
    {

        displayNearestSites = display;

        Generate();

    }

    public void SetNearestEdgesToMouseVisible(bool display)
    {

        displayNearestEdges = display;

        Generate();

    }

    public void SetSpawnSiteMarkers(bool spawn)
    {

        spawnSiteMarkers = spawn;

        Generate();

    }

    public void SetDisplayEdges(bool visible)
    {

        displayEdges = visible;

        Generate();

    }

    public void SetUseFalloff(bool visible)
    {

        useFalloff = visible;

        Generate();

    }

    public void SetUseAltFalloff(bool visible)
    {

        useAltFalloff = visible;

        Generate();

    }

    public void SetColorRange(bool range1)
    {

        this.edgeColorRange1 = range1;

        UpdateSettings();

        Generate();

    }

    //updates the settings depending on the toggles and the input field in the menus
    public void UpdateSettings()
    {

        //get values from inputs, setting defaults in necessary
        if (jitterFractionIF.text != "")
            jitterFraction = float.Parse(jitterFractionIF.text);
        else
            jitterFraction = 2.5f;
        if (jitterFraction <= 0) jitterFraction = 2.5f;
        
        useFalloff = useFalloffToggle.isOn;
        useAltFalloff = useAltFalloffToggle.isOn;

        if (altFalloffMidValueIF.text != "")
            midValue = float.Parse(altFalloffMidValueIF.text);
        else
            midValue = 0;
        if (midValue < 0) midValue = 0;
        else if (midValue > 1) midValue = 1;

        if (falloffDistanceIF.text != "")
            falloffDistance = float.Parse(falloffDistanceIF.text);
        else
            falloffDistance = 10;
        if (falloffDistance <= 0) falloffDistance = 10;

        displayEdges = displayEdgesToggle.isOn;
        if (edgeWidthIF.text != "")
            edgeWidth = float.Parse(edgeWidthIF.text);
        else
            edgeWidth = 2;
        if (edgeColorRIF.text != "")
            edgeColorRGBA.x = float.Parse(edgeColorRIF.text);
        else
            edgeColorRGBA.x = 0;
        if (edgeColorGIF.text != "")
            edgeColorRGBA.y = float.Parse(edgeColorGIF.text);
        else
            edgeColorRGBA.y = 0;
        if (edgeColorBIF.text != "")
            edgeColorRGBA.z = float.Parse(edgeColorBIF.text);
        else
            edgeColorRGBA.z = 0;
        edgeColorRGBA.w = 1;
        edgeColorRange1 = edgeColorRange1Toggle.isOn;

        //format edge color depending on range
        if (edgeColorRange1)
        {

            //make sure all inputs are properly in range
            edgeColorRGBA.x = Mathf.Clamp01(edgeColorRGBA.x);
            edgeColorRGBA.y = Mathf.Clamp01(edgeColorRGBA.y);
            edgeColorRGBA.z = Mathf.Clamp01(edgeColorRGBA.z);
            edgeColorRGBA.w = Mathf.Clamp01(edgeColorRGBA.w);

        }
        else
        {

            //make sure all inputs are properly in range
            edgeColorRGBA.x = Mathf.Clamp(edgeColorRGBA.x,0,255);
            edgeColorRGBA.y = Mathf.Clamp(edgeColorRGBA.y, 0, 255);
            edgeColorRGBA.z = Mathf.Clamp(edgeColorRGBA.z, 0, 255);
            edgeColorRGBA.w = Mathf.Clamp(edgeColorRGBA.w, 0, 255);

            //format the value to the range the shader uses
            edgeColorRGBA /= 255;

        }

        spawnSiteMarkers = siteMarkersToggle.isOn;

        seed = seedIF.text;

    }

    //pass all the info to the shader
    public void Generate()
    {
        //init the property block
        propBlock = new MaterialPropertyBlock();

        //get the material we want to pass the stuff to
        Renderer renderer = GetComponent<Renderer>();

        //declare and init sites index
        //to keep track of where we are in our array
        int sitesIndex = 0;

        //remove all siteMarkers since we might be making new ones
        foreach(GameObject go in siteMarkers)
            if(go!=null)
                Destroy(go);

        siteMarkers.Clear();

        //for every grid position starting in top left
        //the condition is comparing the coordinate (int) with a float in case of an odd number so we get all the points we wanted
        //otherwise we would get one less
        for (int x = -size.x; x < size.x; x++)
        {

            for (int y = size.y; y > -size.y; y--)
            {

                //make a new random stream using the hashcode of the string composed of the position of the current site as the seed
                //each point has unique coordinates -> unique seed
                UnityEngine.Random.InitState(("" + x + "" + y + seed).GetHashCode());

                //calculate jitter in x and y
                float jitterX = UnityEngine.Random.Range(-1 / jitterFraction, 1 / jitterFraction);
                float jitterY = UnityEngine.Random.Range(-1 / jitterFraction, 1 / jitterFraction);

                //get which biome will this site be
                //really just float between 0 and 1 used to multiply grayscale value returned by fragment shader
                float biome = UnityEngine.Random.value;

                //set the site position and its biome
                //in case of an even coordinate, we add 0.5, otherwise the sites will be off center
                //we then divide the position by the plane size so that all sites are within the plane
                //position of the site is two dimensional  in x and z since were viewing the world from the top
                //w in our vector4 will be used to store which biome this site corresponds to
                sites[sitesIndex++] = new Vector4(x + (size.x % 2f == 0 ? 0.5f : 0f) + jitterX, y - (size.y % 2f == 0 ? 0.5f : 0f) + jitterY, 0, biome);

                //For debugging, if we want, spawn markers showing where the sites are
                if (spawnSiteMarkers)
                {
                    siteMarkers.Add(GameObject.CreatePrimitive(PrimitiveType.Sphere));
                    siteMarkers[siteMarkers.Count - 1].transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
                    siteMarkers[siteMarkers.Count - 1].transform.position = new Vector3(x + (size.x % 2f == 0 ? 0.5f : 0f) + jitterX, y - (size.y % 2f == 0 ? 0.5f : 0f) + jitterY, 0);
                    
                    //color the marker black or white depending on which would have highest contrast with biome
                    float colorScale = biome > 0.5 ? 0f : 1f;
                    Renderer markerRenderer = siteMarkers[siteMarkers.Count - 1].GetComponent<Renderer>();
                    markerRenderer.material.shader = Shader.Find("Unlit/Color");
                    markerRenderer.material.color = new Color(colorScale, colorScale, colorScale);
                }


            }

        }

        //pass our sites to the material
        propBlock.SetVectorArray("Sites", sites);

        //pass the falloff settings
        propBlock.SetFloat("UseFalloff", useFalloff ? 1 : 0);
        propBlock.SetFloat("UseAltFalloff", useAltFalloff ? 1 : 0);
        propBlock.SetFloat("ForcedMidValue", midValue);

        //pass falloff distance to the material
        propBlock.SetFloat("FalloffDistance", falloffDistance);

        //pass the edge display settings
        propBlock.SetFloat("DisplayEdges", displayEdges ? 1 : 0);
        propBlock.SetFloat("EdgeWidth", edgeWidth);
        propBlock.SetVector("EdgeColor", edgeColorRGBA);

        //pass mouse pos relative settings
        propBlock.SetFloat("DisplayNearestSites", displayNearestSites ? 1 : 0);
        propBlock.SetFloat("DisplayNearestEdges", displayNearestEdges ? 1 : 0);

        renderer.SetPropertyBlock(propBlock);
    }

}
