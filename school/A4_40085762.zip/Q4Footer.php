<footer>
    <a id="footerText" href="Q4Statement.php">Privacy/Disclaimer Statement</a>
</footer>