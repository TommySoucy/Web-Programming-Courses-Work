<?php
session_start();

$hotels=Array();

if(isset($_GET['search'])){

    $hotels=file("hotels.txt");

    $size=sizeof($hotels);

}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Q4</title>
    <link rel="stylesheet" type="text/css" href="Q4Style.css" />
    <script src="a3q5.js" ></script>
</head>
<body>
    <?php include "Q4Header.php"; ?>
    <form id="searchForm" method="get" action="Q4Home.php">
        <input type="text" name="searchQuery">
        <input type="submit" name="search" value="Search" >
    </form>
    <table <?php if(isset($_GET['search'])) echo "id='searchResults'"; ?>>
        <?php

        if(sizeof($hotels)>0){

            $minimum=false;

            foreach($hotels as $hotel){

                if(strstr($hotel,$_GET['searchQuery'])){

                    $minimum=true;

                    $currentHotel=preg_split("/:/",$hotel);

                    $name=$currentHotel[0];
                    $location=$currentHotel[1];
                    $address=$currentHotel[2];
                    $numOfRooms=$currentHotel[3];
                    $special=$currentHotel[4];
                    $price=trim($currentHotel[5]);

                    echo "<tr><td class='searchResult' >";
                    if(isset($_SESSION['user']))
                        echo "<strong>Name:&nbsp</strong>$name<br>";
                    echo "<strong>Location:&nbsp</strong>$location</td>";
                    if(isset($_SESSION['user']))
                        echo "<td class='searchResult' ><strong>Number of rooms:&nbsp</strong>$numOfRooms<br><strong>Facilities:&nbsp</strong>$special</td><td class='searchResult' ><strong>Price:&nbsp</strong>$$price/night</td>";
                    if(!isset($_SESSION['user']))
                        echo "<td class='searchResult' ><a href='Q4LoginSignUp.php' class='button'>Login to view info</a></td>";
                    echo "</tr>";

                }

            }

            if(!$minimum){

                echo "<tr><td>No search results</td></tr>";

            }

        }

        ?>
    </table>
    <?php include "Q4Footer.php"; ?>
</body>
</html>