<script>
    function updateTime(){

        var s="";

        var time=new Date();

        s="Tommy's Hotel "+format(time.getHours())+":"+format(time.getMinutes())+":"+format(time.getSeconds());

        document.getElementById("title").innerHTML=s;

    }

    function format(s){

        if((s+"").length===1){

            return ""+0+s;

        }else{

            return s;

        }

    }

    setInterval(updateTime,1000);
</script>
<header>
    <div id="headerHome">
        <p><a href="Q4Home.php">Home</a></p>
    </div>
    <div id="headerTitle">
        <table>
            <tr>
                <td><a href="Q4Home.php"><img src="hotel.png" alt="Hotel icon" width="100"/></a></td>
                <td><h1 id="title">Tommy's Hotel <?php date_default_timezone_set("America/New_York"); echo date("H:i:s"); ?></h1></td>
            </tr>
        </table>
    </div>
    <div id="headerLogin">
        <p><?php if(isset($_SESSION['user'])) echo "Welcome, ".$_SESSION['user']."&nbsp&nbsp"; ?><a href="Q4LoginSignUp.php"><?php if(isset($_SESSION['user'])) echo "Logout"; else echo "Login or Sign up" ?></a></p>
    </div>
</header>