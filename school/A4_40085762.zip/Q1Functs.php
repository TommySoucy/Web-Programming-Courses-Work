<?php

function findSummation($num){

    $sum=0;

    for($i=1;$i<=$num;$i++){

        $sum+=$i;

    }

    return $sum;

}

function uppercaseFirstandLastSorted($s){

    $words=explode(" ",$s);
    $result='';

    sort($words);

    for($i=0;$i<sizeof($words);$i++){

        $words[$i]=ucfirst($words[$i]);
        $words[$i]=strrev(ucfirst(strrev($words[$i])));

        if($i==sizeof($words)-1){

            $result.=$words[$i];

        }else{

            $result.=$words[$i].' ';

        }

    }

    return $result;

}

function findAverage_and_Median($nums){

    sort($nums);

    $sum=0;
    $median=-1;

    for($i=0;$i<sizeof($nums);$i++){

        $sum+=$nums[$i];

        if(sizeof($nums)%2==0&&$i==((sizeof($nums)/2)-1)){

            $median=($nums[$i]+$nums[$i+1])/2;

        }else if(sizeof($nums)%2!=0&&$i==round(sizeof($nums)/2,0,PHP_ROUND_HALF_DOWN)){

            $median=$nums[$i];

        }

    }

    return array($sum/sizeof($nums),$median);

}

function find4Digits($s){

    preg_match('/(\d\d\d\d)/', $s, $matches);

    return $matches[0];

}