<?php
require("Q1Functs.php");
echo findSummation(5);
echo "<br>";
echo uppercaseFirstandLastSorted("i am a human");
echo "<br>";
echo "Average: ".findAverage_and_Median(Array(1,2,3))[0]." and median: ".findAverage_and_Median(Array(1,2,3))[1];
echo "<br>";
echo find4Digits("53 614 35 3 3174 54 380");