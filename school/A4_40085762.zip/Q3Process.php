<?php
$nameFormatCorrect=false;
$numFormatCorrect=false;
if(preg_match("/(\(\d\d\d\)-\d\d\d-\d\d\d\d)/",$_GET["phoneNum"])){

    $numFormatCorrect=true;

    echo "Entered phone number is valid.<br>";

}else{

    echo "Entered phone number is invalid.<br>";

}
if(preg_match("/^[A-Z][a-z]*/",$_GET["lastName"])){

    $nameFormatCorrect=true;

    echo "Entered last name is valid.";

}else{

    echo "Entered last name is invalid.";

}