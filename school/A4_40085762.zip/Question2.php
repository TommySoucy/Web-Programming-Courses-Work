<?php

date_default_timezone_set("America/Toronto");

if(!isset($_COOKIE["numOfVisits"])){

    $_COOKIE["numOfVisits"]=1;

    $count=$_COOKIE["numOfVisits"]+1;

    $length=time()+3600*24*365;

    setcookie("numOfVisits", $count, $length);

}else{

    $count=$_COOKIE["numOfVisits"]+1;

    $length=time()+3600*24*365;

    setcookie("numOfVisits", $count, $length);

}

echo "You've visited this page ".$_COOKIE["numOfVisits"]." times.<br>";

if(!isset($_COOKIE["lastVisit"])){

    setcookie("lastVisit",date("d/m/y")." at ".date("H:i:s")." ".date_default_timezone_get(),time()+3600*24*365);

}else{

    echo "Last time you visited this page on : ".$_COOKIE["lastVisit"];

    setcookie("lastVisit",date("d/m/y")." at ".date("H:i:s")." ".date_default_timezone_get(),time()+3600*24*365);

}