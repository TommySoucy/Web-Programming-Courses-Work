<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Q4</title>
    <link rel="stylesheet" type="text/css" href="Q4Style.css" />
    <script src="a3q5.js" ></script>
</head>
<body>
    <?php include "Q4Header.php"; ?>
    <h1 id="statement">Our users' private info will not be sold or misused and the site builder cannot be held accountable for anything.</h1>
    <h2 id="statement">Hotel icon by Ivan Ryabokon on iconfinder.com</h2>
    <?php include "Q4Footer.php"; ?>
</body>
</html>