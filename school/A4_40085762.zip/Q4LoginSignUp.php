<?php

session_start();

//This page is also used to logout, so whenever we come here its either to login (were were logged out) or to logout
//so either way unset session and destroy it as we will later start a new one is we log in
//making a check here to see if someone is logged in and then logging them out causes trouble with starting one again later when we login as one might already have been started
//it can therefore give an error
session_unset();
session_destroy();

$signIn=true;

$usernameValid=true;
$usernameErr=Array();

$passwordValid=true;
$passwordErr=Array();

$passwordConfirmValid=true;

if(file_exists("accounts.txt"))

    $accounts=file("accounts.txt");

else{

    $accountsFile=fopen("accounts.txt","wr");
    $accounts=file("accounts.txt");

}

$newAccount=false;

if(isset($_POST['signIn'])){

    if(empty($_POST['username'])){

        $usernameValid=false;

    }

    if(empty($_POST['password'])){

        $passwordValid=false;

    }

    if($usernameValid&&$passwordValid&&correctAccount($_POST['username'],$_POST['password'],$accounts)){

        session_start();

        $_SESSION['user']=$_POST['username'];

        header("Location: Q4Home.php");

    }else{

        $passwordErr[]="Invalid login";

    }

}else if(isset($_POST['signUp'])){

    $signIn=false;

    if(!empty($_POST['username'])){

        if(preg_match("/\W/",$_POST['username'])){

            $usernameErr[]="Username should only contain letters and numbers";

            $usernameValid=false;

        }

        if(preg_match("/_/",$_POST['username'])){

            $usernameErr[]="Username cannot contain underscores";

            $usernameValid=false;

        }

        if(usernameAlreadyUsed($_POST['username'],$accounts)){

            $usernameErr[]="Username already in use";

            $usernameValid=false;

        }

    }else{

        $usernameValid=false;

    }

    if(!empty($_POST['password'])){

        if(strlen($_POST['password'])<6) {

            $passwordErr[] = "Password should be at least 6 characters long";

            $passwordValid=false;

        }

        if(!(preg_match("/[a-z]/",$_POST['password'])||preg_match("/[A-Z]/",$_POST['password']))){

            $passwordErr[]="Password should have at least 1 letter";

            $passwordValid=false;

        }

        if(!(preg_match("/\W/",$_POST['password'])||preg_match("/[0-9]/",$_POST['password']))){

            $passwordErr[]="Password should contain at least one digit or special character";

            $passwordValid=false;

        }

    }else{

        $passwordValid=false;

    }

    if(!empty($_POST['passwordConfirm'])&&$_POST['password']===$_POST['passwordConfirm']) {

        if ($usernameValid && $passwordValid) {

            file_put_contents("accounts.txt",$_POST['username'] . ':' . $_POST['password'] . PHP_EOL,FILE_APPEND);

            $newAccount=true;

        }

    }else{

        $passwordConfirmValid=false;

    }

}

function usernameAlreadyUsed($username,$accounts){

    foreach ($accounts as $account)

        if(preg_split("/:/",$account)[0]===$username)

            return true;

    return false;

}

function correctAccount($username,$password,$accounts){

    foreach ($accounts as $account) {

        if (preg_split("/:/", $account)[0] === $username && trim(preg_split("/:/", $account)[1]) === $password) {

            return true;

        }

    }

    return false;

}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Q4</title>
    <link rel="stylesheet" type="text/css" href="Q4Style.css" />
    <script src="a3q5.js" ></script>
</head>
<body>
    <?php include "Q4Header.php"; ?>
    <form id="signInForm" method="post" action="Q4LoginSignUp.php">
        <fieldset>
            <legend>Sign in</legend>
            <table>
                <tr>
                    <td>
                        <label <?php if(!$usernameValid) echo "class='err'"; ?>><strong>Username:</strong></label><br/>
                        <input type="text" name="username"><br/>
                    </td>
                </tr>
                <?php

                //check if we are in signin or signup
                if($signIn===false){
                    //we are in signup

                    //check if there were errors with the username
                    if(sizeof($usernameErr)>0){

                        echo "<tr>
                                <td colspan='2'>
                                  <ul class='err'>";

                        foreach($usernameErr as $err){

                            echo "<li>$err</li>";

                        }

                        echo "</ul>
                            </td>
                          </tr>";

                    }

                }

                ?>
                <tr>
                    <td>
                        A username can contain letters and digits only<br><br>
                    </td>
                </tr>
                <tr>
                    <td>
                        <label <?php if(!$passwordValid) echo "class='err'"; ?>><strong>Password:</strong></label><br/>
                        <input type="password" name="password">
                    </td>
                    <td class="bottom" id="signIn">
                        <input id="signInButton" type="submit" name="signIn" value="Sign In" >
                    </td>
                </tr>
                <?php

                //check if we are in signin or singup
                if($signIn===false){
                    //we are in signup

                    //check if there were errors with the password
                    if(sizeof($passwordErr)>0){

                        echo "<tr>
                                <td colspan='2'>
                                  <ul class='err'>";

                        foreach($passwordErr as $err){

                            echo "<li>$err</li>";

                        }

                        echo "</ul>
                            </td>
                          </tr>";

                    }

                }else{
                    //we are in signin

                    if(sizeof($passwordErr)>0){

                        echo "<tr>
                                <td colspan='2'>
                                  <ul class='err'>";

                        foreach($passwordErr as $err){

                            echo "<li>$err</li>";

                        }

                        echo "</ul>
                            </td>
                          </tr>";

                    }

                }

                ?>
                <tr>
                    <td>
                        A password must be at least 6 characters long,<br>have at least one letter and at least one digit.
                    </td>
                </tr>
            </table>
        </fieldset>
        <fieldset>
            <legend>Sign up</legend>
            <table>
                <tr>
                    <td>
                        <label <?php if(!$passwordConfirmValid) echo "class='err'"; ?>><strong>Re-enter password:</strong></label><br/>
                        <input type="password" name="passwordConfirm"><br/>
                    </td>
                    <td class="bottom" id="signUp">
                        <input id="signUpButton" type="submit" name="signUp" value="Sign Up" >
                    </td>
                </tr>
            </table>
        </fieldset>
    </form>
    <?php

    if($newAccount){

        echo "<div class='center'><h1>New account created, you may now login.</h1></div>";

    }

    ?>
    <?php include "Q4Footer.php"; ?>
</body>
</html>